import { useState, useEffect } from 'react';

// Component for App Header
const Header = () => {
  return (
    <header className="bg-gray-900 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-2xl font-bold">Movie Explorer</h1>
        <nav>
          <ul className="flex space-x-4">
            <li><button className="hover:text-blue-400">Home</button></li>
            <li><button className="hover:text-blue-400">Favorites</button></li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

// Component for Login Form
const LoginForm = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = () => {
    onLogin(username);
  };

  return (
    <div className="bg-gray-800 p-8 rounded-lg shadow-lg max-w-md mx-auto mt-12">
      <h2 className="text-2xl font-bold text-white mb-6 text-center">Login to Movie Explorer</h2>
      <div>
        <div className="mb-4">
          <label className="block text-gray-300 mb-2" htmlFor="username">Username</label>
          <input
            className="w-full p-2 rounded bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-blue-500"
            id="username"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="mb-6">
          <label className="block text-gray-300 mb-2" htmlFor="password">Password</label>
          <input
            className="w-full p-2 rounded bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-blue-500"
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          onClick={handleSubmit}
        >
          Sign In
        </button>
      </div>
    </div>
  );
};

// Movie Card Component
const MovieCard = ({ movie, onSelect }) => {
  return (
    <div 
      className="bg-gray-800 rounded-lg overflow-hidden shadow-lg cursor-pointer transform hover:scale-105 transition-transform duration-200"
      onClick={() => onSelect(movie)}
    >
      <img 
        src={movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : "/api/placeholder/300/450"} 
        alt={movie.title} 
        className="w-full h-64 object-cover"
      />
      <div className="p-4">
        <h3 className="text-xl font-bold text-white mb-2">{movie.title}</h3>
        <div className="flex justify-between text-gray-400 text-sm">
          <span>{movie.release_date?.substring(0, 4) || 'N/A'}</span>
          <span className="flex items-center">
            <svg className="w-4 h-4 text-yellow-500 mr-1" fill="currentColor" viewBox="0 0 20 20">
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
            {movie.vote_average ? movie.vote_average.toFixed(1) : 'N/A'}
          </span>
        </div>
      </div>
    </div>
  );
};

// Grid of Movie Posters Component
const MovieGrid = ({ movies, onSelectMovie }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 my-8">
      {movies.map(movie => (
        <MovieCard 
          key={movie.id} 
          movie={movie} 
          onSelect={onSelectMovie}
        />
      ))}
    </div>
  );
};

// Search Bar Component
const SearchBar = ({ onSearch }) => {
  const [query, setQuery] = useState('');

  const handleSubmit = (e) => {
    if (e) e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  return (
    <div className="my-6">
      <div className="flex">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search for movies..."
          className="flex-grow p-3 rounded-l bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-blue-500"
          onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
        />
        <button
          onClick={handleSubmit}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 rounded-r font-medium"
        >
          Search
        </button>
      </div>
    </div>
  );
};

// Movie Details Component
const MovieDetails = ({ movie, onClose, onAddToFavorites }) => {
  const [trailer, setTrailer] = useState(null);

  useEffect(() => {
    // In a real app, we would fetch videos from TMDb API
    // For now, we'll just simulate this
    setTrailer({
      key: 'dQw4w9WgXcQ', // Example YouTube ID
      site: 'YouTube'
    });
  }, [movie.id]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 rounded-lg max-w-4xl w-full max-h-screen overflow-y-auto">
        <div className="relative">
          <img 
            src={movie.backdrop_path ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}` : "/api/placeholder/800/450"} 
            alt={movie.title} 
            className="w-full h-64 object-cover opacity-50"
          />
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 bg-black bg-opacity-50 text-white p-2 rounded-full hover:bg-opacity-75"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
          <div className="absolute bottom-4 left-4">
            <h2 className="text-3xl font-bold text-white">{movie.title}</h2>
            <p className="text-gray-300">{movie.release_date?.substring(0, 4) || 'N/A'}</p>
          </div>
        </div>
        
        <div className="p-6">
          <div className="flex flex-wrap mb-6">
            <div className="mr-4 mb-2">
              <span className="bg-blue-600 text-white text-sm font-medium px-3 py-1 rounded-full">
                Rating: {movie.vote_average ? movie.vote_average.toFixed(1) : 'N/A'}/10
              </span>
            </div>
            {movie.genres && movie.genres.map(genre => (
              <div key={genre.id} className="mr-2 mb-2">
                <span className="bg-gray-700 text-gray-300 text-sm font-medium px-3 py-1 rounded-full">
                  {genre.name}
                </span>
              </div>
            ))}
          </div>
          
          <p className="text-gray-300 mb-6">{movie.overview}</p>
          
          {trailer && (
            <div className="mb-6">
              <div className="w-full h-64 bg-gray-900 flex items-center justify-center">
                <p className="text-white">YouTube trailer would be embedded here</p>
              </div>
            </div>
          )}
          
          <div className="flex justify-between">
            <button 
              onClick={() => onAddToFavorites(movie)}
              className="bg-gray-700 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded"
            >
              Add to Favorites
            </button>
            <button
              className="bg-gray-700 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded inline-flex items-center"
            >
              More Info
              <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Trending Movies Section
const TrendingMovies = ({ movies, onSelectMovie }) => {
  return (
    <div className="my-8">
      <h2 className="text-2xl font-bold text-white mb-4">Trending Movies</h2>
      <div className="flex space-x-4 overflow-x-auto pb-4">
        {movies.map(movie => (
          <div 
            key={movie.id}
            className="flex-shrink-0 w-48 cursor-pointer"
            onClick={() => onSelectMovie(movie)}
          >
            <img 
              src={movie.poster_path ? `https://image.tmdb.org/t/p/w300${movie.poster_path}` : "/api/placeholder/200/300"} 
              alt={movie.title} 
              className="w-full h-64 object-cover rounded-lg"
            />
            <div className="mt-2">
              <h3 className="text-white font-medium truncate">{movie.title}</h3>
              <p className="text-gray-400 text-sm">{movie.release_date?.substring(0, 4) || 'N/A'}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Filter Component
const MovieFilters = ({ onFilterChange }) => {
  const [genre, setGenre] = useState('');
  const [year, setYear] = useState('');
  const [rating, setRating] = useState('');
  
  const handleFilterChange = () => {
    onFilterChange({ genre, year, rating });
  };

  return (
    <div className="bg-gray-800 p-4 rounded-lg mb-6">
      <h3 className="text-white font-medium mb-3">Filter Movies</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-gray-300 mb-1 text-sm">Genre</label>
          <select 
            className="w-full p-2 rounded bg-gray-700 text-white border border-gray-600"
            value={genre}
            onChange={(e) => setGenre(e.target.value)}
          >
            <option value="">All Genres</option>
            <option value="28">Action</option>
            <option value="12">Adventure</option>
            <option value="16">Animation</option>
            <option value="35">Comedy</option>
            <option value="80">Crime</option>
            <option value="99">Documentary</option>
            <option value="18">Drama</option>
            <option value="10751">Family</option>
            <option value="14">Fantasy</option>
            <option value="36">History</option>
            <option value="27">Horror</option>
            <option value="10402">Music</option>
            <option value="9648">Mystery</option>
            <option value="10749">Romance</option>
            <option value="878">Science Fiction</option>
            <option value="53">Thriller</option>
            <option value="10752">War</option>
            <option value="37">Western</option>
          </select>
        </div>
        <div>
          <label className="block text-gray-300 mb-1 text-sm">Year</label>
          <select 
            className="w-full p-2 rounded bg-gray-700 text-white border border-gray-600"
            value={year}
            onChange={(e) => setYear(e.target.value)}
          >
            <option value="">All Years</option>
            {[...Array(30)].map((_, i) => (
              <option key={i} value={2024 - i}>
                {2024 - i}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-gray-300 mb-1 text-sm">Minimum Rating</label>
          <select 
            className="w-full p-2 rounded bg-gray-700 text-white border border-gray-600"
            value={rating}
            onChange={(e) => setRating(e.target.value)}
          >
            <option value="">Any Rating</option>
            <option value="7">7+</option>
            <option value="8">8+</option>
            <option value="9">9+</option>
          </select>
        </div>
      </div>
      <button 
        onClick={handleFilterChange}
        className="mt-4 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded w-full md:w-auto"
      >
        Apply Filters
      </button>
    </div>
  );
};

// Main App Component
export default function MovieExplorer() {
  const [user, setUser] = useState(null);
  const [searchResults, setSearchResults] = useState([]);
  const [trendingMovies, setTrendingMovies] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [favorites, setFavorites] = useState([]);
  const [lastSearched, setLastSearched] = useState('');

  // Mock API functions (in a real app these would connect to TMDb)
  const fetchTrendingMovies = async () => {
    setIsLoading(true);
    try {
      // Simulating API call - in a real app, this would be:
      // const response = await fetch('https://api.themoviedb.org/3/trending/movie/week?api_key=YOUR_API_KEY');
      // const data = await response.json();
      
      // Mock response
      setTimeout(() => {
        const mockResults = [
          {
            id: 1,
            title: "Dune: Part Two",
            overview: "Follow the mythic journey of Paul Atreides as he unites with Chani and the Fremen while on a path of revenge against the conspirators who destroyed his family.",
            poster_path: null,
            backdrop_path: null,
            release_date: "2024-03-01",
            vote_average: 8.2
          },
          {
            id: 2,
            title: "Inside Out 2",
            overview: "Teenage Riley experiences new emotions as she navigates the challenges of adolescence.",
            poster_path: null,
            backdrop_path: null,
            release_date: "2024-06-14",
            vote_average: 8.5
          },
          {
            id: 3,
            title: "Deadpool & Wolverine",
            overview: "Wade Wilson teams up with Logan for an action-packed adventure across the multiverse.",
            poster_path: null,
            backdrop_path: null,
            release_date: "2024-07-26",
            vote_average: 8.0
          },
          {
            id: 4,
            title: "Gladiator II",
            overview: "The sequel to the epic historical drama follows a new hero in ancient Rome.",
            poster_path: null,
            backdrop_path: null,
            release_date: "2024-11-22",
            vote_average: 7.8
          },
          {
            id: 5,
            title: "Furiosa",
            overview: "A prequel to Mad Max: Fury Road chronicling the origins of Furiosa before she teamed up with Max Rockatansky.",
            poster_path: null,
            backdrop_path: null,
            release_date: "2024-05-24",
            vote_average: 7.9
          }
        ];
        setTrendingMovies(mockResults);
        setIsLoading(false);
      }, 500);
    } catch (err) {
      setError('Failed to fetch trending movies');
      setIsLoading(false);
    }
  };

  const searchMovies = async (query) => {
    setIsLoading(true);
    try {
      // Simulating API call - in a real app, this would be:
      // const response = await fetch(`https://api.themoviedb.org/3/search/movie?api_key=YOUR_API_KEY&query=${query}`);
      // const data = await response.json();
      
      // Save the last searched movie to local storage
      localStorage.setItem('lastSearchedMovie', query);
      setLastSearched(query);
      
      // Mock response
      setTimeout(() => {
        const mockResults = [
          {
            id: 10,
            title: query + " - The Movie",
            overview: "A fictional movie based on your search.",
            poster_path: null,
            backdrop_path: null,
            release_date: "2024-05-15",
            vote_average: 7.5
          },
          {
            id: 11,
            title: "The Legend of " + query,
            overview: "An epic adventure featuring characters from your search query.",
            poster_path: null,
            backdrop_path: null,
            release_date: "2023-11-03",
            vote_average: 6.9
          },
          {
            id: 12,
            title: query + " Returns",
            overview: "The sequel to the blockbuster hit based on your search.",
            poster_path: null,
            backdrop_path: null,
            release_date: "2024-08-21",
            vote_average: 8.1
          }
        ];
        
        setSearchResults(mockResults);
        setIsLoading(false);
        setPage(1);
      }, 800);
    } catch (err) {
      setError('Failed to search movies');
      setIsLoading(false);
    }
  };

  const handleFilterChange = (filters) => {
    // In a real app, this would make an API call with the filter parameters
    console.log('Filtering with:', filters);
    // Mock implementation - just show a loading state
    setIsLoading(true);
    setTimeout(() => {
      setSearchResults(prev => {
        // Apply some mock filtering
        return prev.map(movie => ({
          ...movie,
          // Just a mock change to show filtering happened
          title: movie.title + " (Filtered)"
        }));
      });
      setIsLoading(false);
    }, 500);
  };

  const handleLogin = (username) => {
    setUser({ username });
    
    // Load favorites from local storage
    const savedFavorites = localStorage.getItem('favoriteMovies');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
    
    // Load last searched movie
    const lastMovie = localStorage.getItem('lastSearchedMovie');
    if (lastMovie) {
      setLastSearched(lastMovie);
      searchMovies(lastMovie);
    }
    
    // Fetch trending movies on login
    fetchTrendingMovies();
  };

  const handleLoadMore = () => {
    setIsLoading(true);
    setPage(prev => prev + 1);
    
    // Simulating loading more results
    setTimeout(() => {
      const newResults = [
        {
          id: 100 + Math.random() * 100,
          title: "Additional Movie " + page,
          overview: "This appears after clicking load more.",
          poster_path: null,
          backdrop_path: null,
          release_date: "2024-01-01",
          vote_average: 7.0
        },
        {
          id: 100 + Math.random() * 100,
          title: "More Content " + page,
          overview: "Another movie that appears after clicking load more.",
          poster_path: null,
          backdrop_path: null,
          release_date: "2024-02-15",
          vote_average: 6.8
        }
      ];
      
      setSearchResults(prev => [...prev, ...newResults]);
      setIsLoading(false);
    }, 800);
  };

  const addToFavorites = (movie) => {
    setFavorites(prev => {
      const newFavorites = [...prev, movie];
      // Save to local storage
      localStorage.setItem('favoriteMovies', JSON.stringify(newFavorites));
      return newFavorites;
    });
  };

  const toggleDarkMode = () => {
    // This would toggle dark/light mode in a real implementation
    console.log('Toggle dark/light mode');
  };

  useEffect(() => {
    // Handle API errors gracefully
    const handleApiError = (error) => {
      console.error("API Error:", error);
      setError("An error occurred while fetching data. Please try again.");
    };
    
    window.addEventListener('error', handleApiError);
    
    return () => {
      window.removeEventListener('error', handleApiError);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      {user ? (
        <>
          <Header />
          <main className="container mx-auto px-4 py-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl">Welcome, {user.username}</h2>
              <button 
                onClick={toggleDarkMode}
                className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-full"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"></path>
                </svg>
              </button>
            </div>
            
            <SearchBar onSearch={searchMovies} />
            
            {lastSearched && (
              <p className="text-gray-400 mb-4">Last searched: "{lastSearched}"</p>
            )}
            
            <MovieFilters onFilterChange={handleFilterChange} />
            
            {trendingMovies.length > 0 && (
              <TrendingMovies 
                movies={trendingMovies} 
                onSelectMovie={setSelectedMovie} 
              />
            )}
            
            {searchResults.length > 0 && (
              <>
                <h2 className="text-2xl font-bold text-white mb-4">Search Results</h2>
                <MovieGrid 
                  movies={searchResults} 
                  onSelectMovie={setSelectedMovie} 
                />
                
                <div className="flex justify-center my-8">
                  <button 
                    onClick={handleLoadMore}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-8 rounded"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Loading...' : 'Load More'}
                  </button>
                </div>
              </>
            )}
            
            {isLoading && searchResults.length === 0 && trendingMovies.length === 0 && (
              <div className="flex justify-center my-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
              </div>
            )}
            
            {error && (
              <div className="bg-red-600 text-white p-4 rounded-lg my-4">
                {error}
              </div>
            )}
            
            {selectedMovie && (
              <MovieDetails 
                movie={selectedMovie} 
                onClose={() => setSelectedMovie(null)} 
                onAddToFavorites={addToFavorites}
              />
            )}
          </main>
        </>
      ) : (
        <LoginForm onLogin={handleLogin} />
      )}
    </div>
  );
}